package com.schoolmanagementsystem.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.schoolmanagementsystem.model.Subject;

public interface SubjectRepository extends CrudRepository<Subject, String>{
	
	Subject findBySubjectNameAndTimeDuration(String subjectName,Integer timeDuration);
	
//	@Query("select timeDuration from subject u")
//	Integer countByTimeDuration(); 
//	
//	@Query("select timeDuration from subject u group by u.facultyAllotted")
//	Integer countByTimeDuration(Integer timeDuration); 
	
}
