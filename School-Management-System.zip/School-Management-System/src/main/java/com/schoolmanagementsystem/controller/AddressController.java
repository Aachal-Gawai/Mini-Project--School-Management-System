package com.schoolmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.schoolmanagementsystem.model.Address;
import com.schoolmanagementsystem.service.AddressService;

@RestController
public class AddressController {
	@Autowired
	AddressService addressservice;
	
	@GetMapping("/address")  
	private List<Address> getAllAddress()   
	{  
	return addressservice.getAllAddress();  
	}  
	
	@PostMapping("/address")
	private String addStudent(@RequestBody Address address) {
		addressservice.saveOrUpdate(address);
		return "Successfully added";
	}
	
	@PutMapping("/address")
	private String updateStudent(@RequestBody Address address) {
		addressservice.saveOrUpdate(address);
		return "Successfully update";
	}
	
	@DeleteMapping("/address")
	private String deleteStudent(@RequestBody Address address) {
		addressservice.delete(address);
		return "Successfully deleted";
	}
	

}
