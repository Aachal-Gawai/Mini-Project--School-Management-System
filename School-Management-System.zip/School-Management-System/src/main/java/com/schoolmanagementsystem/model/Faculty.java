package com.schoolmanagementsystem.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Faculty {
	
	
	@Id
	private Integer facultyId;
	private String name;
	private String gender;
	private String address;
	private Integer departmentId;
	private Integer standardAllotted;
	private Integer contactNumber;
	
	public Faculty() {}
	
	public Faculty(String name, String gender, Integer facultyId, String address, Integer departmentId,
			Integer standardAllotted, Integer contactNumber) {
		super();
		this.name = name;
		this.gender = gender;
		this.facultyId = facultyId;
		this.address = address;
		this.departmentId = departmentId;
		this.standardAllotted = standardAllotted;
		this.contactNumber = contactNumber;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Integer getFacultyId() {
		return facultyId;
	}
	public void setFacultyId(Integer facultyId) {
		this.facultyId = facultyId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	public Integer getStandardAllotted() {
		return standardAllotted;
	}
	public void setStandardAllotted(Integer standardAllotted) {
		this.standardAllotted = standardAllotted;
	}
	public Integer getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(Integer contactNumber) {
		this.contactNumber = contactNumber;
	}
}
