package com.schoolmanagementsystem.controllerTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schoolmanagementsystem.controller.StudentController;
import com.schoolmanagementsystem.model.Address;
import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.service.StudentService;


@WebMvcTest(StudentController.class)
class ControllerTest {
	
	 @Autowired
	private MockMvc mockMvc;

	@MockBean
	private StudentService studentservice;
	
	 @Autowired
	private ObjectMapper mapper = new ObjectMapper();

	 

	@Test
	public void controllersava() throws Exception {
		
		Faculty f=new Faculty();
		f.setFacultyId(11);
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("KP");
		Subject sub=new Subject();
		sub.setSubjectName("Math");
	
	Student s=new Student();
	s.setStudentId(10);
	s.setStudentName("Aachal");
	s.setFaculty(f);
	s.setAddress(a);
	s.setSubjectsAllotted(sub);

	when(studentservice.saveOrUpdate(Mockito.any(Student.class))).thenReturn("Successfully save");
	String json = mapper.writeValueAsString(s);
	RequestBuilder requestBuilder = MockMvcRequestBuilders
			.post("/student")
			.content(json)
			.contentType(MediaType.APPLICATION_JSON);

    MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
	String actualResponseBody = mvcResult.getResponse().getContentAsString();
	String expected="Successfully save";
	assertThat(actualResponseBody).isEqualToIgnoringWhitespace(expected);
}
	
	
	@Test
	public void controllerGet() throws Exception {
		List<Student> students=new ArrayList<>();
		Faculty f=new Faculty();
		f.setFacultyId(11);
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("KP");
		Subject sub=new Subject();
		sub.setSubjectName("Math");
	
	Student s=new Student();
	s.setStudentId(10);
	s.setStudentName("Aachal");
	s.setFaculty(f);
	s.setAddress(a);
	s.setSubjectsAllotted(sub);
	
	students.add(s);

	when(studentservice.getAllStudent()).thenReturn(students);
	String json = mapper.writeValueAsString(s);
	RequestBuilder requestBuilder = MockMvcRequestBuilders
			.get("/student")
			.content(json)
			.contentType(MediaType.APPLICATION_JSON);
	 MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
	 String actualResponseBody = mvcResult.getResponse().getContentAsString();
	 JSONAssert.assertEquals("[{studentId:10}]", actualResponseBody, false);
	 
	}
	
	@Test
	public void controllerupdate() throws Exception {
		
		Faculty f=new Faculty();
		f.setFacultyId(11);
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("KP");
		Subject sub=new Subject();
		sub.setSubjectName("Math");
	
	Student s=new Student();
	s.setStudentId(10);
	s.setStudentName("Aachal");
	s.setFaculty(f);
	s.setAddress(a);
	s.setSubjectsAllotted(sub);

	when(studentservice.saveOrUpdate(Mockito.any(Student.class))).thenReturn("Successfully update");
	String json = mapper.writeValueAsString(s);
	RequestBuilder requestBuilder = MockMvcRequestBuilders
			.put("/student")
			.content(json)
			.contentType(MediaType.APPLICATION_JSON);

    MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
	String actualResponseBody = mvcResult.getResponse().getContentAsString();
	String expected="Successfully update";
	assertThat(actualResponseBody).isEqualToIgnoringWhitespace(expected);
}
	
	
	@Test
	public void controllerdelete() throws Exception {
		List<Student> students=new ArrayList<>();
		Faculty f=new Faculty();
		f.setFacultyId(11);
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("KP");
		Subject sub=new Subject();
		sub.setSubjectName("Math");
	
	Student s=new Student();
	s.setStudentId(10);
	s.setStudentName("Aachal");
	s.setFaculty(f);
	s.setAddress(a);
	s.setSubjectsAllotted(sub);
	
	students.add(s);

	when(studentservice.getAllStudent()).thenReturn(students);
	String json = mapper.writeValueAsString(s);
	RequestBuilder requestBuilder = MockMvcRequestBuilders
			.delete("/student")
			.content(json)
			.contentType(MediaType.APPLICATION_JSON);
	 MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
	 String actualResponseBody = mvcResult.getResponse().getContentAsString();
		String expected="Successfully deleted";
		assertThat(actualResponseBody).isEqualToIgnoringWhitespace(expected);
	 
	}
	
}
