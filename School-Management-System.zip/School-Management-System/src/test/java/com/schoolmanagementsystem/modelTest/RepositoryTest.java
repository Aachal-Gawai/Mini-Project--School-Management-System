package com.schoolmanagementsystem.modelTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.repository.StudentRepository;
import com.schoolmanagementsystem.service.StudentService;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class RepositoryTest {

	@Autowired
	StudentRepository studentrepository;
	
	@Autowired
	StudentService studentservice;
	
	
	
	@Test
	@Order(1)
	public void testcreate() {
		Student s=new Student();
		s.setStudentId(10);
		s.setStudentName("Aachal");
		studentrepository.save(s);
		assertNotNull(studentrepository.findById(10).get());
	}
	
	@Test
	@Order(2)
	public void read() {
		List<Student> s=(List<Student>) studentrepository.findAll();
		assertThat(s).size().isGreaterThan(0);
		
	}
	
	@Test
	@Order(3)
	public void readsingle() {
		Student s=studentrepository.findById(10).get();
		assertEquals(10,s.getStudentId());
	}
	
	@Test
	@Order(4)
	public void update() {
		Student s=studentrepository.findById(10).get();
		s.setStudentName("Priyanka");
		studentrepository.save(s);
		assertNotEquals("Aachal", s.getStudentName());
	}
	
	@Test
	@Order(5)
	public void delete() {
		studentrepository.deleteById(10);
		assertThat(studentrepository.existsById(10)).isFalse();
	}


}
