package com.schoolmanagementsystem.serviceTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.schoolmanagementsystem.model.Address;
import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.repository.StudentRepository;
import com.schoolmanagementsystem.service.StudentService;
@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class ServiceTest {

	@Autowired
	StudentRepository studentrepository;
	
	@Autowired
	StudentService studentservice;
	
	@Test
	public void seviceSava() {
		Faculty f=new Faculty();
		f.setFacultyId(11);
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("KP");
		Subject sub=new Subject();
		sub.setSubjectName("Math");
		
	Student s=new Student();
	s.setStudentId(10);
	s.setStudentName("Aachal");
	s.setFaculty(f);
	s.setAddress(a);
	s.setSubjectsAllotted(sub);
	
	

	
	assertEquals("Successfully save", studentservice.saveOrUpdate(s));
	}
	
	
	@Test
	public void serviceget() {
		Faculty f=new Faculty();
		f.setFacultyId(11);
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("KP");
		Subject sub=new Subject();
		sub.setSubjectName("Math");
		
	Student s=new Student();
	s.setStudentId(10);
	s.setStudentName("Aachal");
	s.setFaculty(f);
	s.setAddress(a);
	s.setSubjectsAllotted(sub);
	studentservice.saveOrUpdate(s);
	List<Student> s1=studentservice.getAllStudent();
	assertThat(s1).size().isGreaterThan(0);
	}
	
	@Test
	public void servicedelete() {
		Faculty f=new Faculty();
		f.setFacultyId(11);
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("KP");
		Subject sub=new Subject();
		sub.setSubjectName("Math");
		
	Student s=new Student();
	s.setStudentId(10);
	s.setStudentName("Aachal");
	s.setFaculty(f);
	s.setAddress(a);
	s.setSubjectsAllotted(sub);
	studentservice.saveOrUpdate(s);
	studentservice.delete(s);
	assertThat(studentrepository.existsById(10)).isFalse();

	
	}
	


}
