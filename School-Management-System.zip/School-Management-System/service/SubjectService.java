package com.schoolmanagementsystem.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.repository.StudentRepository;
import com.schoolmanagementsystem.repository.SubjectRepository;

@Service
public class SubjectService {
	@Autowired
	SubjectRepository subjectrepository;

	@Autowired
	StudentRepository studentrepository;
	
	public List<Subject> getAllSubject()   
	{  
	List<Subject> subject = new ArrayList<Subject>();  
	subjectrepository.findAll().forEach(Subject -> subject.add(Subject));  
	return subject;  
	}  
	
	public void saveOrUpdate(Subject subject)   
	{  
		subjectrepository.save(subject);  
		
	}  
	
	public void delete(Subject Subject)   
	{  
		subjectrepository.delete(Subject);  
	}  
	public void validateSubject(Student student) {
		Subject subject=subjectrepository.findBySubjectNameAndTimeDuration(student.getSubjectsAllotted().getSubjectName(), student.getSubjectsAllotted().getTimeDuration());
		if(subject!=null) {
			student.setSubjectsAllotted(subject);
	}
	}	
	
	
	
/*
	public void validateSubject(Student student) {
//		List<Subject> subject=student.getSubjectsAllotted();
//		List<Subject> s=new ArrayList<>();
//		for(int i=0;i<subject.size();i++){
//			Subject sub=subjectrepository.findBySubjectNameAndTimeDuration(subject.get(i).getSubjectName(), subject.get(i).getTimeDuration());
//				if(sub==null) 
//				{
//					s.add(sub);
//					System.out.println("Yes");
//					
//			     }
//				else {
//					s.add(subject.get(i));
//					System.out.println("no");
//				}
//				}
		System.out.println(student.getSubjectsAllotted());
		List<Subject> subject=student.getSubjectsAllotted();
		for(int i=0;i<subject.size();i++){
		Subject sub=subjectrepository.findBySubjectNameAndTimeDuration(subject.get(i).getSubjectName(), subject.get(i).getTimeDuration());
		System.out.println(subject.get(i));
		System.out.println(sub);
		if(sub==null) {
//			student.getSubjectsAllotted().get(i).setFacultyAllotted(subject.get(i).getFacultyAllotted());
//			student.getSubjectsAllotted().get(i).setStandardAllotted(subject.get(i).getStandardAllotted());
//			student.getSubjectsAllotted().get(i).setSubjectName(subject.get(i).getSubjectName());
//			student.getSubjectsAllotted().get(i).setTimeDuration(subject.get(i).getTimeDuration());
            
			System.out.println("null");
		}
		else {
			student.getSubjectsAllotted().get(i).setFacultyAllotted(sub.getFacultyAllotted());
			student.getSubjectsAllotted().get(i).setStandardAllotted(sub.getStandardAllotted());
			student.getSubjectsAllotted().get(i).setSubjectName(sub.getSubjectName());
			student.getSubjectsAllotted().get(i).setTimeDuration(sub.getTimeDuration());
			student.setSubjectsAllotted(subject);
			
			System.out.println("not null");
			System.out.println(student.getSubjectsAllotted().get(i));
		}
		}
		}
		
	*/	
		
	

	}
