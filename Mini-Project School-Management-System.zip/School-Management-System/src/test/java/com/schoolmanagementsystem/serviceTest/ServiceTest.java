package com.schoolmanagementsystem.serviceTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.internal.matchers.Any;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.schoolmanagementsystem.model.Address;
import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.repository.StudentRepository;
import com.schoolmanagementsystem.service.StudentService;

import jakarta.persistence.FetchType;
import jakarta.transaction.Transactional;
@SpringBootTest
class ServiceTest {
	

	@Autowired
	StudentRepository studentrepository;
	
	@Autowired
	StudentService studentservice;
	
	@Test
	public void seviceSava() {
		
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);

		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math1");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		
		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		s1.setFacultyAllotted(f1);
		
		Subject s2=new Subject();
		s2.setSubjectName("English1");
		s2.setStandardAllotted("1");
		s2.setTimeDuration(45);
		
		Faculty f2=new Faculty();
		f2.setFacultyId(2);
		f2.setName("Priyanka");
		f2.setAddress(a);
		f2.setContactNumber(22222222);
		f2.setDepartmentId(10);
		f2.setGender("F");
		s2.setFacultyAllotted(f2);
		
		subject.add(s1);
		subject.add(s2);	
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);
	
	assertEquals("Sucessfully save", studentservice.saveOrUpdate(s));
	}
	
	
	@Test
	@Transactional
	public void serviceget() {
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);
		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math1");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		
		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		s1.setFacultyAllotted(f1);
		
		Subject s2=new Subject();
		s2.setSubjectName("English1");
		s2.setStandardAllotted("1");
		s2.setTimeDuration(45);
		
		Faculty f2=new Faculty();
		f2.setFacultyId(2);
		f2.setName("Priyanka");
		f2.setAddress(a);
		f2.setContactNumber(22222222);
		f2.setDepartmentId(10);
		f2.setGender("F");
		s2.setFacultyAllotted(f2);
		
		subject.add(s1);
		subject.add(s2);	
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);
	
	studentservice.saveOrUpdate(s);
	List<Student> stu=studentservice.getAllStudent();
	assertThat(stu).size().isGreaterThan(0);
	}
	
	@Test
	public void servicedelete() {
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);
		
		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math1");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		
		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		s1.setFacultyAllotted(f1);
		
		Subject s2=new Subject();
		s2.setSubjectName("English1");
		s2.setStandardAllotted("1");
		s2.setTimeDuration(45);
		
		Faculty f2=new Faculty();
		f2.setFacultyId(2);
		f2.setName("Priyanka");
		f2.setAddress(a);
		f2.setContactNumber(22222222);
		f2.setDepartmentId(10);
		f2.setGender("F");
		s2.setFacultyAllotted(f2);
		
		subject.add(s1);
		subject.add(s2);	
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);
	
	studentservice.saveOrUpdate(s);
	studentservice.delete(s);
	assertThat(studentrepository.existsById(10)).isFalse();

	
	}
	
	

	@Test
	public void validatesubjectimemore45() {
		
		Address a=new Address();
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setCity("Pune");
		a.setPinCode(411040);
		
		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		
		Faculty f2=new Faculty();
		f2.setFacultyId(2);
		f2.setName("Priyanka");
		f2.setAddress(a);
		f2.setContactNumber(22222222);
		f2.setDepartmentId(10);
		f2.setGender("F");
		
	
		List<Subject> subject1=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math1");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		s1.setFacultyAllotted(f1);
		
		Subject s2=new Subject();
		s2.setSubjectName("English1");
		s2.setStandardAllotted("1");
		s2.setTimeDuration(55);
		s2.setFacultyAllotted(f2);
		
		subject1.add(s1);
		subject1.add(s2);	
		
	    Student student1=new Student();
	    student1.setStudentId(1);
	    student1.setStudentName("Aachal");
	    student1.setAddress(a);
	    student1.setSubjectsAllotted(subject1);



	
	assertEquals("Subject Time more that 45 min", studentservice.saveOrUpdate(student1));
	}
	
	


}
