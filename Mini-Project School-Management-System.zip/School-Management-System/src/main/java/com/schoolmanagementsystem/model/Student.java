package com.schoolmanagementsystem.model;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;


@Entity
public class Student {
	@Id
	private Integer studentId;
	private String studentName;
	@OneToOne(cascade = CascadeType.ALL)
	private Address address;
	private String gender;
	private String standard;
	private Integer classTeacherId;
	private Integer emergencyContactNumber;

	@ManyToMany(cascade = CascadeType.ALL)
	private List<Subject> subjectsAllotted;
	
//	@ManyToMany(cascade = CascadeType.ALL)
//	private List<Faculty> faculty;
	
	public Student() {}

	public Student(Integer studentId, String studentName, Address address, String gender, String standard,
			Integer classTeacherId, Integer emergencyContactNumber, List<Subject> subjectsAllotted) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.address = address;
		this.gender = gender;
		this.standard = standard;
		this.classTeacherId = classTeacherId;
		this.emergencyContactNumber = emergencyContactNumber;
		this.subjectsAllotted = subjectsAllotted;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public Integer getClassTeacherId() {
		return classTeacherId;
	}

	public void setClassTeacherId(Integer classTeacherId) {
		this.classTeacherId = classTeacherId;
	}

	public Integer getEmergencyContactNumber() {
		return emergencyContactNumber;
	}

	public void setEmergencyContactNumber(Integer emergencyContactNumber) {
		this.emergencyContactNumber = emergencyContactNumber;
	}

	public List<Subject> getSubjectsAllotted() {
		return subjectsAllotted;
	}

	public void setSubjectsAllotted(List<Subject> subjectsAllotted) {
		this.subjectsAllotted = subjectsAllotted;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", address=" + address + ", gender="
				+ gender + ", standard=" + standard + ", classTeacherId=" + classTeacherId + ", emergencyContactNumber="
				+ emergencyContactNumber + ", subjectsAllotted=" + subjectsAllotted + "]";
	}

	
}
