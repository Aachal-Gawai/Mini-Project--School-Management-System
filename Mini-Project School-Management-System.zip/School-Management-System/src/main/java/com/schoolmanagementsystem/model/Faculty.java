package com.schoolmanagementsystem.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Faculty {
	
	@Id
	private Integer facultyId;
	private String name;
	private String gender;
	@OneToOne(cascade = CascadeType.ALL)
	private Address address;
	private Integer departmentId;
	private Integer contactNumber;
	
	public Faculty() {}

	public Faculty(Integer facultyId, String name, String gender, Address address, Integer departmentId,
			Integer contactNumber) {
		super();
		this.facultyId = facultyId;
		this.name = name;
		this.gender = gender;
		this.address = address;
		this.departmentId = departmentId;
		this.contactNumber = contactNumber;
	}

	public Integer getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(Integer facultyId) {
		this.facultyId = facultyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public Integer getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Integer contactNumber) {
		this.contactNumber = contactNumber;
	}

	@Override
	public String toString() {
		return "Faculty [facultyId=" + facultyId + ", name=" + name + ", gender=" + gender + ", address=" + address
				+ ", departmentId=" + departmentId + ", contactNumber=" + contactNumber + "]";
	}

	
}
