package com.schoolmanagementsystem.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
public class Subject {
	@Id
	private String subjectName;
//	private String facultyAllotted;
	@ManyToOne(cascade = {CascadeType.ALL},fetch = FetchType.EAGER)
	Faculty facultyAllotted;
	private String standardAllotted;
	private Integer timeDuration;


	public Subject() {}

public Subject(String subjectName, Faculty facultyAllotted, String standardAllotted, Integer timeDuration) {
	super();
	this.subjectName = subjectName;
	this.facultyAllotted = facultyAllotted;
	this.standardAllotted = standardAllotted;
	this.timeDuration = timeDuration;
}

public String getSubjectName() {
	return subjectName;
}

public void setSubjectName(String subjectName) {
	this.subjectName = subjectName;
}

public Faculty getFacultyAllotted() {
	return facultyAllotted;
}

public void setFacultyAllotted(Faculty facultyAllotted) {
	this.facultyAllotted = facultyAllotted;
}

public String getStandardAllotted() {
	return standardAllotted;
}

public void setStandardAllotted(String standardAllotted) {
	
	this.standardAllotted = standardAllotted;
}

public Integer getTimeDuration() {
	return timeDuration;
}

public void setTimeDuration(Integer timeDuration) {
	this.timeDuration = timeDuration;
}

@Override
public String toString() {
	return "Subject [subjectName=" + subjectName + ", facultyAllotted=" + facultyAllotted + ", standardAllotted="
			+ standardAllotted + ", timeDuration=" + timeDuration + "]";
}

	

	
}
