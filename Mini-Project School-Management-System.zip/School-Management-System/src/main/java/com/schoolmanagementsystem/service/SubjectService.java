package com.schoolmanagementsystem.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.repository.StudentRepository;
import com.schoolmanagementsystem.repository.SubjectRepository;

@Service
public class SubjectService {
	@Autowired
	SubjectRepository subjectrepository;

	@Autowired
	FacultyService facultyservice;
	
	
	public List<Subject> getAllSubject()   
	{  
	List<Subject> subject = new ArrayList<Subject>();  
	subjectrepository.findAll().forEach(Subject -> subject.add(Subject));  
	return subject;  
	}  
	
	public void saveOrUpdate(Subject subject)   
	{  
		facultyservice.validateFaculty(subject.getFacultyAllotted());
		subjectrepository.save(subject);  
		
	}  
	
	public void delete(Subject Subject)   
	{  
		subjectrepository.delete(Subject);  
	}  
	
	public void validateSubject(Student student) {
		List<Subject> subject=student.getSubjectsAllotted();
		for(int i=0;i<subject.size();i++) {
		Subject sub=subjectrepository.findBySubjectNameAndTimeDuration(subject.get(i).getSubjectName(), subject.get(i).getTimeDuration());
		if(sub==null) {
			subjectrepository.save(subject.get(i));
	     }
		}
       }	
	}
