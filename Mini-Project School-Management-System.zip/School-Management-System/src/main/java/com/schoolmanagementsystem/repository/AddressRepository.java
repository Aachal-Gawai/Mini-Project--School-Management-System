package com.schoolmanagementsystem.repository;

import org.springframework.data.repository.CrudRepository;

import com.schoolmanagementsystem.model.Address;

public interface AddressRepository extends CrudRepository<Address, String>{
	
	Address findByCityAndAddressLine1AndAddressLine2AndPinCodeAndCountry(String city, String addressLine1,
			String addressLine2, Integer pinCode, String country);	

}
