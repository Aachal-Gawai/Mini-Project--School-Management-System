package com.schoolmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	StudentService studentservice;
	@GetMapping("/student")  
	private List<Student> getAllStudent()   
	{  
	return studentservice.getAllStudent();  
	}  
	
	@PostMapping("/student")
	private String addStudent(@RequestBody Student student) {
		return (studentservice.saveOrUpdate(student));
		
	}
	
	@PutMapping("/student")
	private String updateStudent(@RequestBody Student student) {
		studentservice.saveOrUpdate(student);
		return "Successfully update";
	}
	
	@DeleteMapping("/student")
	private String deleteStudent(@RequestBody Student student) {
		studentservice.delete(student);
		return "Successfully deleted";
	}
	
}
