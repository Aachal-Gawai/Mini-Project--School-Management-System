package com.schoolmanagementsystem.service;

import java.util.ArrayList;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolmanagementsystem.model.Address;
import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.repository.AddressRepository;
import com.schoolmanagementsystem.repository.FacultyRepository;
import com.schoolmanagementsystem.repository.StudentRepository;
import com.schoolmanagementsystem.repository.SubjectRepository;

@Service
public class StudentService {
	@Autowired
	StudentRepository studentrepository;
	
	@Autowired
	AddressService addressService;
	
	@Autowired
	FacultyService facultyService;
	
	@Autowired
	SubjectService subjectService;
	
	public List<Student> getAllStudent()   
	{  
	List<Student> student = new ArrayList<Student>();  
	studentrepository.findAll().forEach(Student -> student.add(Student));  
	return student;  
	}  
	
	public String saveOrUpdate(Student student)   
	{ 
		long c=studentrepository.count();
		System.out.println(c);
		System.out.println("GROUP By");
		System.out.println(studentrepository.countByStandard(student.getStandard()));
		if(studentrepository.countByStandard(student.getStandard())==null || studentrepository.countByStandard(student.getStandard())<30){
		facultyService.validateFaculty(student);
		addressService.validateAddress(student);
		subjectService.validateSubject(student);
		studentrepository.save(student);
		return "Sucessfully save";
		}
		else {
			return "30 student are present in class";
		}
			
	}  
		
	public void delete(Student student)   
	{  
	studentrepository.delete(student);  
	} 
    
	

}
