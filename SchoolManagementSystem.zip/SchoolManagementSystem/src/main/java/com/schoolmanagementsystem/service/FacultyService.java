package com.schoolmanagementsystem.service;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.repository.FacultyRepository;

@Service
public class FacultyService {
	@Autowired
	FacultyRepository facultyrepository;
	
	public List<Faculty> getAllFaulty()   
	{  
	List<Faculty> faulty = new ArrayList<Faculty>();  
	facultyrepository.findAll().forEach(Faculty -> faulty.add(Faculty));  
	return faulty;  
	}  
	
	public void saveOrUpdate(Faculty faulty)   
	{  
		facultyrepository.save(faulty);  
	}  
	
	public void delete(Faculty faulty)   
	{  
		facultyrepository.delete(faulty);  
	}  
	
	public void validateFaculty(Student student){
		Faculty faculty=facultyrepository.findByNameAndGenderAndContactNumber(student.getFaculty().getName(), student.getFaculty().getGender(), student.getFaculty().getContactNumber());
		if(faculty!=null) {
			student.setFaculty(faculty);
		}
	}
	
	
		
			
}
