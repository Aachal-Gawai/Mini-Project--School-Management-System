package com.schoolmanagementsystem.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.service.SubjectService;

@RestController
public class SubjectController {
	@Autowired
	SubjectService subjectservice;
	@GetMapping("/subject")  
	private List<Subject> getAllSubject()   
	{  
	return subjectservice.getAllSubject();
	}  
	
	@PostMapping("/subject")
	private String addStudent(@RequestBody Subject subject) {
		subjectservice.saveOrUpdate(subject);
		return "Successfully added";
	}
	
	@PutMapping("/subject")
	private String updateStudent(@RequestBody Subject subject) {
		subjectservice.saveOrUpdate(subject);
		return "Successfully update";
	}
	
	@DeleteMapping("/subject")
	private String deleteStudent(@RequestBody Subject subject) {
		subjectservice.delete(subject);
		return "Successfully deleted";
	}
	
}
