package com.schoolmanagementsystem.repository;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.schoolmanagementsystem.model.Student;

@Repository("studentrepository")
public interface StudentRepository extends CrudRepository<Student, Integer>{

	@Query("select count(u) from Student u group by u.standard")
	Integer countByStandard(String standard);

}
