package com.schoolmanagementsystem.model;

import java.util.List;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;


@Entity
public class Student {
	@Id
	private Integer studentId;
	private String studentName;
	@OneToOne(cascade = CascadeType.ALL)
	private Address address;
	private String gender;
	private String standard;
	private Integer classTeacherId;
	private Integer emergencyContactNumber;

	@OneToOne(cascade = CascadeType.ALL)
	private Subject subjectsAllotted;
	@OneToOne(cascade = CascadeType.ALL)
	private Faculty faculty;
	
	public Student() {}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public Integer getClassTeacherId() {
		return classTeacherId;
	}

	public void setClassTeacherId(Integer classTeacherId) {
		this.classTeacherId = classTeacherId;
	}

	public Integer getEmergencyContactNumber() {
		return emergencyContactNumber;
	}

	public void setEmergencyContactNumber(Integer emergencyContactNumber) {
		this.emergencyContactNumber = emergencyContactNumber;
	}

	public Subject getSubjectsAllotted() {
		return subjectsAllotted;
	}

	public void setSubjectsAllotted(Subject subjectsAllotted) {
		this.subjectsAllotted = subjectsAllotted;
	}

	public Faculty getFaculty() {
		return faculty;
	}

	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}

	public Student(Integer studentId, String studentName, Address address, String gender, String standard,
			Integer classTeacherId, Integer emergencyContactNumber, Subject subjectsAllotted, Faculty faculty) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.address = address;
		this.gender = gender;
		this.standard = standard;
		this.classTeacherId = classTeacherId;
		this.emergencyContactNumber = emergencyContactNumber;
		this.subjectsAllotted = subjectsAllotted;
		this.faculty = faculty;
	}

	
	
	
}
