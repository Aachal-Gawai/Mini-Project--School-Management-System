package com.schoolmanagementsystem.serviceTest;

import static org.assertj.core.api.Assertions.assertThat;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.internal.matchers.Any;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.schoolmanagementsystem.model.Address;
import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.repository.StudentRepository;
import com.schoolmanagementsystem.service.StudentService;

import jakarta.persistence.FetchType;
import jakarta.transaction.Transactional;
@SpringBootTest
class ServiceTest {
	

	@Autowired
	StudentRepository studentrepository;
	
	@Autowired
	StudentService studentservice;
	
	@Test
	@Transactional
	public void seviceSava() {
		
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);

		Faculty f1=new Faculty();
		f1.setFacultyId(2);
		f1.setName("Priyanka");
		f1.setAddress1(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		s1.setFacultyAllotted(f1);		
		subject.add(s1);
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);
	
	assertEquals("Sucessfully save", studentservice.saveOrUpdate(s));
	}
	
	
	@Test
	@Transactional
	public void serviceget() {
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);
		
		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress1(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		s1.setFacultyAllotted(f1);		
		subject.add(s1);
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);
	
	studentservice.saveOrUpdate(s);
	List<Student> stu=studentservice.getAllStudent();
	assertThat(stu).size().isGreaterThan(0);
	}
	
	@Test
	public void servicedelete() {
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);

		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress1(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		s1.setFacultyAllotted(f1);
		
		subject.add(s1);
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);
	
	studentservice.saveOrUpdate(s);
	studentservice.delete(s.getStudentId());
	assertThat(studentrepository.existsById(1)).isFalse();

	
	}
	
	

	@Test
	@Transactional
	public void validatesubjectimemore45() {
		
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);
		
		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress1(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
	
		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(55);
		s1.setFacultyAllotted(f1);
		
		subject.add(s1);
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);

	
	assertEquals("Subject Time more that 45 min", studentservice.saveOrUpdate(s));
	}
	
	


}
