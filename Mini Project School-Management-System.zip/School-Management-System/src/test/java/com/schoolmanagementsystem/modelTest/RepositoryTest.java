package com.schoolmanagementsystem.modelTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.schoolmanagementsystem.model.Address;
import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.repository.StudentRepository;
import com.schoolmanagementsystem.service.StudentService;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
class RepositoryTest {

	@Autowired
	StudentRepository studentrepository;
	
	@Autowired
	StudentService studentservice;
	
	
	
	@Test
	@Order(1)
	public void testcreate() {
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);
		Address a1=new Address();
		a1.setCity("Pune");
		a1.setAddressLine1("ABc");
		a1.setAddressLine2("Hadapsar");
		a1.setCountry("India");
		a1.setPinCode(411040);
		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		
		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress1(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		s1.setFacultyAllotted(f1);
		
		Subject s2=new Subject();
		s2.setSubjectName("English");
		s2.setStandardAllotted("1");
		s2.setTimeDuration(45);
		
		Faculty f2=new Faculty();
		f2.setFacultyId(2);
		f2.setName("Priyanka");
		f2.setAddress1(a);
		f2.setContactNumber(22222222);
		f2.setDepartmentId(10);
		f2.setGender("F");
		s2.setFacultyAllotted(f2);
		
		subject.add(s1);
		subject.add(s2);	
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);
		studentrepository.save(s);
		assertNotNull(studentrepository.findById(1).get());
	}
	
	@Test
	@Order(2)
	public void read() {
		List<Student> s=(List<Student>) studentrepository.findAll();
		assertThat(s).size().isGreaterThan(0);
		
	}
	
	@Test
	@Order(3)
	public void readsingle() {
		Student s=studentrepository.findById(1).get();
		assertEquals(1,s.getStudentId());
	}
	
	@Test
	@Order(4)
	public void update() {
		Student s=studentrepository.findById(1).get();
		s.setStudentName("Priyanka");
		studentrepository.save(s);
		assertNotEquals("Aachal", s.getStudentName());
	}
	
	@Test
	@Order(5)
	public void delete() {
		studentrepository.deleteById(1);
		assertThat(studentrepository.existsById(1)).isFalse();
	}


}
