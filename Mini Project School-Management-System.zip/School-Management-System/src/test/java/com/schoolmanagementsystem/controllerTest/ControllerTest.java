package com.schoolmanagementsystem.controllerTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schoolmanagementsystem.controller.StudentController;
import com.schoolmanagementsystem.model.Address;
import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.service.StudentService;


@WebMvcTest(StudentController.class)
class ControllerTest {
	
	 @Autowired
	private MockMvc mockMvc;

	@MockBean
	private StudentService studentservice;
	
	 @Autowired
	private ObjectMapper mapper = new ObjectMapper();

	 

	@Test
	public void controllersava() throws Exception {
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);
		
		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress1(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		s1.setFacultyAllotted(f1);		
		subject.add(s1);
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);

	when(studentservice.saveOrUpdate(Mockito.any(Student.class))).thenReturn("Successfully save");
	String json = mapper.writeValueAsString(s);
	RequestBuilder requestBuilder = MockMvcRequestBuilders
			.post("/student")
			.content(json)
			.contentType(MediaType.APPLICATION_JSON);

    MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
	String actualResponseBody = mvcResult.getResponse().getContentAsString();
	String expected="Successfully save";
	assertThat(actualResponseBody).isEqualToIgnoringWhitespace(expected);
}
	
	
	@Test
	public void controllerGet() throws Exception {
		List<Student> students=new ArrayList<>();
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);
		
		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress1(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		s1.setFacultyAllotted(f1);		
		subject.add(s1);
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);
	
	students.add(s);

	when(studentservice.getAllStudent()).thenReturn(students);
	String json = mapper.writeValueAsString(s);
	RequestBuilder requestBuilder = MockMvcRequestBuilders
			.get("/student")
			.content(json)
			.contentType(MediaType.APPLICATION_JSON);
	 MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
	 String actualResponseBody = mvcResult.getResponse().getContentAsString();
	 JSONAssert.assertEquals("[{studentId:1}]", actualResponseBody, false);
	 
	}
	
	@Test
	public void controllerupdate() throws Exception {
		
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);
		
		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress1(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		s1.setFacultyAllotted(f1);		
		subject.add(s1);
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);

	when(studentservice.saveOrUpdate(Mockito.any(Student.class))).thenReturn("Successfully update");
	String json = mapper.writeValueAsString(s);
	RequestBuilder requestBuilder = MockMvcRequestBuilders
			.put("/student")
			.content(json)
			.contentType(MediaType.APPLICATION_JSON);

    MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
	String actualResponseBody = mvcResult.getResponse().getContentAsString();
	String expected="Successfully update";
	assertThat(actualResponseBody).isEqualToIgnoringWhitespace(expected);
}
	
	
	@Test
	public void controllerdelete() throws Exception {
		List<Student> students=new ArrayList<>();
		Address a=new Address();
		a.setCity("Pune");
		a.setAddressLine1("NIBM");
		a.setAddressLine2("Hadapsar");
		a.setCountry("India");
		a.setPinCode(411040);
		
		Faculty f1=new Faculty();
		f1.setFacultyId(1);
		f1.setName("Rishu");
		f1.setAddress1(a);
		f1.setContactNumber(111111111);
		f1.setDepartmentId(10);
		f1.setGender("M");
		
		List<Subject> subject=new ArrayList<>();
		Subject s1=new Subject();
		s1.setSubjectName("Math");
		s1.setStandardAllotted("1");
		s1.setTimeDuration(45);
		s1.setFacultyAllotted(f1);		
		subject.add(s1);
		
	Student s=new Student();
	s.setStudentId(1);
	s.setStudentName("Aachal");
	s.setAddress(a);
	s.setSubjectsAllotted(subject);
	
	students.add(s);

	when(studentservice.getAllStudent()).thenReturn(students);
	String json = mapper.writeValueAsString(s);
	RequestBuilder requestBuilder = MockMvcRequestBuilders
			.delete("/student/1")
			.content(json)
			.contentType(MediaType.APPLICATION_JSON);
	 MvcResult mvcResult=mockMvc.perform(requestBuilder).andExpect(status().isOk()).andReturn();
	 String actualResponseBody = mvcResult.getResponse().getContentAsString();
		String expected="Successfully deleted";
		assertThat(actualResponseBody).isEqualToIgnoringWhitespace(expected);
	 
	}
	
}
