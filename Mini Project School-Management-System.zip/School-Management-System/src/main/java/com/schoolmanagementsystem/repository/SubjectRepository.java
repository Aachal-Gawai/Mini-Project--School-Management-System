package com.schoolmanagementsystem.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.schoolmanagementsystem.model.Subject;
@Repository
public interface SubjectRepository extends CrudRepository<Subject, String>{
	
	Subject findBySubjectNameAndTimeDuration(String subjectName,Integer timeDuration);
	
	@Query(value="select * from Subject u", nativeQuery = true)
	List<Subject> subjectall();
	
}
