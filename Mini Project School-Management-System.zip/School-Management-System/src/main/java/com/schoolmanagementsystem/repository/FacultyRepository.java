package com.schoolmanagementsystem.repository;

import org.springframework.data.repository.CrudRepository;

import com.schoolmanagementsystem.model.Faculty;

public interface FacultyRepository extends CrudRepository<Faculty, Integer>{
	Faculty findByNameAndGenderAndContactNumber(String name, String gender, Integer contactNumber);
	
}

