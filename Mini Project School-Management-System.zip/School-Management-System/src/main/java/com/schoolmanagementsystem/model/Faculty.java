package com.schoolmanagementsystem.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Faculty {
	
	@Id
	private Integer facultyId;
	private String name;
	private String gender;
	@OneToOne(cascade = CascadeType.ALL)
	private Address address1;
	private Integer departmentId;
	private Integer contactNumber;
	
	public Faculty() {}

	public Faculty(Integer facultyId, String name, String gender, Address address1, Integer departmentId,
			Integer contactNumber) {
		super();
		this.facultyId = facultyId;
		this.name = name;
		this.gender = gender;
		this.address1 = address1;
		this.departmentId = departmentId;
		this.contactNumber = contactNumber;
	}

	public Integer getFacultyId() {
		return facultyId;
	}

	public void setFacultyId(Integer facultyId) {
		this.facultyId = facultyId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Address getAddress1() {
		return address1;
	}

	public void setAddress1(Address address1) {
		this.address1 = address1;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public Integer getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Integer contactNumber) {
		this.contactNumber = contactNumber;
	}

	@Override
	public String toString() {
		return "Faculty [facultyId=" + facultyId + ", name=" + name + ", gender=" + gender + ", address1=" + address1
				+ ", departmentId=" + departmentId + ", contactNumber=" + contactNumber + "]";
	}

	

	
}
