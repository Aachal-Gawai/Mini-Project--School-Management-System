package com.schoolmanagementsystem.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.schoolmanagementsystem.model.Address;
import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.repository.AddressRepository;

@Service
public class AddressService {
	@Autowired
	AddressRepository addressrepository;
	
	public List<Address> getAllAddress()   
	{  
	List<Address> address = new ArrayList<Address>();  
	addressrepository.findAll().forEach(Address-> address.add(Address));  
	return address;  
	}  
	
	public void saveOrUpdate(Address address)   
	{  
		addressrepository.save(address);  
	}  
	
	public void delete(Address address)   
	{  
		addressrepository.delete(address);  
	}  
	
	
	public void validateAddress(Student student){
		Address add=student.getAddress();
		Address address=addressrepository.findByCityAndAddressLine1AndAddressLine2AndPinCodeAndCountry(student.getAddress().getCity(), student.getAddress().getAddressLine1(), student.getAddress().getAddressLine2(), student.getAddress().getPinCode(), student.getAddress().getCountry());
		if(address==null) {
			addressrepository.save(add);
		}
		
	}
	
	public void validateAddress(Faculty faculty){
		Address add=faculty.getAddress1();
		Address address=addressrepository.findByCityAndAddressLine1AndAddressLine2AndPinCodeAndCountry(faculty.getAddress1().getAddressLine1(), faculty.getAddress1().getAddressLine1(), faculty.getAddress1().getAddressLine2(), faculty.getAddress1().getPinCode(), faculty.getAddress1().getCountry());
		if(address==null) {
			addressrepository.save(add);
		}
		
	}
	
}
