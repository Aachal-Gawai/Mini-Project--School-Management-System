package com.schoolmanagementsystem.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.model.Subject;
import com.schoolmanagementsystem.repository.StudentRepository;
import com.schoolmanagementsystem.repository.SubjectRepository;

@Service
public class StudentService {
	
	@Autowired
	SubjectRepository subjectrepository;
	@Autowired
	StudentRepository studentrepository;
	
	@Autowired
	AddressService addressService;
	
	@Autowired
	FacultyService facultyService;
	
	@Autowired
	SubjectService subjectService;
	
	public List<Student> getAllStudent()   
	{  
	List<Student> student = new ArrayList<Student>();  
	studentrepository.findAll().forEach(Student -> student.add(Student));  
	return student;  
	}  
	
	public String saveOrUpdate(Student student)   
	{ 
		
		//To get the map for faculty and timeduration
		List<Subject> sub=subjectrepository.subjectall();
		Map<Integer, Integer> result=new HashMap<>();
		for(int i=0;i<sub.size();i++) {
		System.out.println(sub.get(i).getFacultyAllotted());
		if(!result.containsKey(sub.get(i).getFacultyAllotted().getFacultyId())) {
			result.put(sub.get(i).getFacultyAllotted().getFacultyId(),sub.get(i).getTimeDuration());

		}
		else {
			int sum=result.get(sub.get(i).getFacultyAllotted().getFacultyId());
			result.replace(sub.get(i).getFacultyAllotted().getFacultyId(),sum+(sub.get(i).getTimeDuration()));
		}
		}
		
		
		
		//validate that subject are not more that 5
		List<Subject> subject=student.getSubjectsAllotted();
		if(subject.size()>5) {
			return "Number of subject more that 5";
		}
		
		//validate that each subject is not more that 45min
		for(int i=0;i<subject.size();i++) {
			if(subject.get(i).getTimeDuration()>45) {
				return "Subject Time more that 45 min";
			}
		
		
	   //validate that each faculty is exceed more than 6 every day
		if(result.containsKey(subject.get(i).getFacultyAllotted().getFacultyId())) {
			int sum=result.get(subject.get(i).getFacultyAllotted().getFacultyId());
			result.replace(sub.get(i).getFacultyAllotted().getFacultyId(),sum+(sub.get(i).getTimeDuration()));
		}
		for(Map.Entry m:result.entrySet()){  
			   System.out.println(m.getKey()+" "+m.getValue());  
			   Integer num=(Integer)m.getValue();
			   if(num>360) {
				   return "Faculty exceed more than 6 every day";
			   }
			  } 
		}
		
		
		
		//validate that each standard have only 30 student
		if(studentrepository.countByStandard(student.getStandard())==null || studentrepository.countByStandard(student.getStandard())<30){
		    for(int i=0;i<student.getSubjectsAllotted().size();i++) {
		    	addressService.validateAddress(student.getSubjectsAllotted().get(i).getFacultyAllotted());
		        facultyService.validateFaculty(student.getSubjectsAllotted().get(i).getFacultyAllotted());
			}
		addressService.validateAddress(student);
		subjectService.validateSubject(student);
		studentrepository.save(student);
		return "Sucessfully save";
		}
		else {
			return "30 student are present in class";
		}
			
	}  
		
	public void delete(Integer studentId)   
	{  
	studentrepository.deleteById(studentId);  
	} 
    
	

}
