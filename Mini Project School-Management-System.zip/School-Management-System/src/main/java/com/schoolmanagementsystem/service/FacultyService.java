package com.schoolmanagementsystem.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.schoolmanagementsystem.model.Faculty;
import com.schoolmanagementsystem.model.Student;
import com.schoolmanagementsystem.repository.FacultyRepository;

@Service
public class FacultyService {
	@Autowired
	FacultyRepository facultyrepository;
	
	@Autowired
	AddressService addressService;
	
	public List<Faculty> getAllFaulty()   
	{  
	List<Faculty> faulty = new ArrayList<Faculty>();  
	facultyrepository.findAll().forEach(Faculty -> faulty.add(Faculty));  
	return faulty;  
	}  
	
	public void saveOrUpdate(Faculty faculty)   
	{  
		addressService.validateAddress(faculty);
		facultyrepository.save(faculty);  
	}  
	
	public void delete(Faculty faculty)   
	{  
		facultyrepository.delete(faculty);  
	}  
	
	public void validateFaculty(Faculty faculty){
			Faculty fac=facultyrepository.findByNameAndGenderAndContactNumber(faculty.getName(), faculty.getGender(), faculty.getContactNumber());
			if(fac==null) {
				facultyrepository.save(faculty);
			}
			
		
	}
	
	
		
			
}
